let msg="hello"
console.log(msg);

//creating server:
const express = require("express");
const app = express();

//getvalidator
const { check, validationResult } = require("express-validator");
let formvalidate = formvalidation();

//running server
app.listen(727, () => {
    console.log("server is running")
})

//routing
app.use("/", express.static("./"))
// put css here IMP!
app.use(express.urlencoded({extended:false}));
app.post("/forminfo", formvalidate,(request, response) => {

    const error = validationResult(request)
    if(!error.isEmpty()){
        const msg = "<h1>Sorry, we found errors with your submission </h1>" + printErrors(error.array());
        
        response.send(msg);
    }
    else{
    const fname = request.body.First_name;
    const lname = request.body.Last_name;
    const emails = request.body.Email;
    const number = request.body.Phone_number;
    const comments = request.body.Comment;
    const files = request.body.File;
    const msg = "<h1>user data received</h1>" + 
                "<p>first name: " + fname + "</p>" +  
                "<p>last name: " + lname + "</p>" + 
                "<p>email: " + emails + "</p>" + 
                "<p>number: " + number + "</p>" + 
                "<p>comments: " + comments + "</p>" + 
                "<p>files: " + files + "</p>";

                addUser(fname, lname, emails, number, comments, files);

    response.send(msg);
    }
});
function formvalidation(){
    return[
        check('First_name').isLength({min:1, max:20}).withMessage("first name must be between 1 and 20 characters.").isString().withMessage("first name must be string").isAlpha().trim().escape(),
        check('Last_name').isLength({min:1, max:30}).withMessage("last name must be between 1 and 30 characters.").isString().withMessage("last name must be string").isAlpha().trim().escape(),
        check('Email').isEmail().trim().escape(),
        check('Phone_number').isLength({min:9, max:10}).withMessage("number must be between 9 and 10 numbers.").isNumeric().trim().escape(),
        check('Comment').isLength({min:0, max:1000}).withMessage("exceeded the comment limit").escape(),
        check('File').escape()
    ]
    
}
function printErrors(errArray){
    let error = [];
    for (let index = 0; index < errArray.length; index++) {
        let err = errArray[index]["msg"];
        let msg = "<p>-"+err+"</p>";
        error.push(msg);
    }
    return error.join("");
}
function addUser(fname, lname, emails, number, comments, files){
    //establish connection
    const mysql = require("mysql2");
    let db = mysql.createConnection({
        host: 'localhost',
        user:'root',
        password:'root',
        port:'3306',
        database:'formdb'
    })
    db.connect(function(err){
        //sql commands
        let sql = "INSERT INTO form_db (fname, lname, emails, number, comments, files) VALUES ('"+fname+"','"+lname+"', '"+emails+"', '"+number+"','"+comments+"', '"+files+"')";
    

  

    //execute command
    db.query(sql, function(err, result){
        if(err) throw err;

        console.log("record added.");
    })
})
}
