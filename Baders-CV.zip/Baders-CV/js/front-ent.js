const form = document.querySelector("#myform");
const msg = document.querySelector("#errmsg");

form.addEventListener('submit', e=>{
    let errmessages = [];
    

    const fname = document.querySelector("#f_name").value.trim();
    if(fname.length<1){
        errmessages.push("please enter your name");

    }
    if(!fname.match("[a-zA-Z]+")){
        errmessages.push("Please enter correct first name format.")
    }


    const lname = document.querySelector("#l_name").value.trim();
    if(lname.length<1){
        errmessages.push("please enter your last name");

    }
    if(!lname.match("[a-zA-Z]+")){
        errmessages.push("Please enter correct last name.")
    }



    const email = document.querySelector("#email").value.trim();
    if(email.length<1){
        errmessages.push("please enter your email");

    }
    if(!email.match("[a-z0-9]+@[a-z]+\.[a-z]{2,4}")){
        errmessages.push("Please enter correct email format.")
    }


    const phonenum = document.querySelector("#phoneno").value.trim();
    if(phonenum.length<1){
        errmessages.push("please enter your phone number");

    }
    if(!phonenum.match("[0-9]{10}")){
        errmessages.push("please correct number format");

    }


    
    if(errmessages.length>0){
       //this will prevent use to submit form.
       e.preventDefault();
       msg.innerHTML = errmessages.join(", ");
    }

    
})
function blurevent1(){
    let name = document.querySelector("#f_name");
    name.value = name.value.charAt(0).toUpperCase() + name.value.substring(1);
}
function blurevent2(){
    let name = document.querySelector("#l_name");
    name.value = name.value.charAt(0).toUpperCase() + name.value.substring(1);
}
function print(){
    alert("You are printing my CV! Thank you");
}
function welcome(){
    alert("Welcome to my CV!");
}
function formwelcome(){
    alert("Please fill out the form to contact me!");
}

var std = new Array("asma", "mohamed", "bashayer", "ali", "bayen");
function searcharray(){
    let enteredname = document.querySelector("#input").value;
    if(std.includes(enteredname) = true){
        document.write("it is in the array");
    }
    else{
        document.write("its not in the array");
    }


}